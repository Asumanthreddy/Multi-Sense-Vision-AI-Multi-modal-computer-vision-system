import mediapipe as mp

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

def detect_hands(img, img_rgb):
    fingers = 0
    zoom = 1.0
    results = hands.process(img_rgb)

    if results.multi_hand_landmarks:
        for hand in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(img, hand, mp_hands.HAND_CONNECTIONS)
            lm = hand.landmark

            if lm[4].x > lm[3].x:
                fingers += 1
            for tip in [8, 12, 16, 20]:
                if lm[tip].y < lm[tip-2].y:
                    fingers += 1

    if fingers == 1:
        zoom = 1.6
    elif fingers == 5:
        zoom = 1.0

    return fingers, zoom
