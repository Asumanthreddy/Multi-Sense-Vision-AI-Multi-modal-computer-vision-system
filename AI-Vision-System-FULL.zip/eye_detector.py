import mediapipe as mp

mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(refine_landmarks=True)

def detect_eye_direction(img_rgb):
    direction = "No Face"
    results = face_mesh.process(img_rgb)

    if results.multi_face_landmarks:
        f = results.multi_face_landmarks[0]
        ratio = (f.landmark[468].x - f.landmark[33].x) / (f.landmark[133].x - f.landmark[33].x)
        if ratio < 0.35:
            direction = "LEFT"
        elif ratio > 0.65:
            direction = "RIGHT"
        else:
            direction = "CENTER"
    return direction
