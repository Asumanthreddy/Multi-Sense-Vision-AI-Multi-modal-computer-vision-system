import mediapipe as mp
import cv2

mp_face = mp.solutions.face_detection
face_detection = mp_face.FaceDetection(0, 0.6)

def detect_faces(img, img_rgb):
    count = 0
    h, w = img.shape[:2]
    results = face_detection.process(img_rgb)

    if results.detections:
        for d in results.detections:
            box = d.location_data.relative_bounding_box
            x1, y1 = int(box.xmin*w), int(box.ymin*h)
            x2, y2 = int((box.xmin+box.width)*w), int((box.ymin+box.height)*h)
            cv2.rectangle(img, (x1,y1), (x2,y2), (255,0,0), 2)
            count += 1
    return count
