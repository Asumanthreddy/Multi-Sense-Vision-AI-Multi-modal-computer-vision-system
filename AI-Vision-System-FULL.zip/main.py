import cv2
from hand_detector import detect_hands
from face_detector import detect_faces
from eye_detector import detect_eye_direction
from object_detector import detect_objects

letter_map = {0:"NONE",1:"A",2:"B",3:"C",4:"D",5:"E",6:"F",7:"G",8:"H",9:"I",10:"J"}

cap = cv2.VideoCapture(0)

while True:
    ret, img = cap.read()
    if not ret:
        break

    img = cv2.flip(img, 1)
    h, w = img.shape[:2]
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    fingers, zoom = detect_hands(img, img_rgb)
    if zoom != 1.0:
        nw, nh = int(w/zoom), int(h/zoom)
        x1, y1 = (w-nw)//2, (h-nh)//2
        img = cv2.resize(img[y1:y1+nh, x1:x1+nw], (w,h))

    faces = detect_faces(img, img_rgb)
    eyes = detect_eye_direction(img_rgb)
    detect_objects(img)

    letter = letter_map.get(fingers, "WORD")

    cv2.rectangle(img, (0,0), (850,140), (0,0,0), -1)
    cv2.putText(img, f"Fingers: {fingers}", (20,35), 0, 1, (0,255,0), 2)
    cv2.putText(img, f"Letter: {letter}", (20,70), 0, 1, (255,255,0), 2)
    cv2.putText(img, f"Faces: {faces}", (20,105), 0, 1, (0,200,255), 2)
    cv2.putText(img, f"Eyes: {eyes}", (350,60), 0, 1, (255,100,255), 2)

    cv2.imshow("AI Vision System", img)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
