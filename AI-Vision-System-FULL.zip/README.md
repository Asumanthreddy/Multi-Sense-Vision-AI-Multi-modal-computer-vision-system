AI Vision System Modular Project

Run:
pip install -r requirements.txt
python main.py
